"""
Ejercicio4
Escribir nombre y cantidad de habitantes de ciudades sin repetirse y termina cuando ponga 0, generar diccionario.
Cuando termine de crear el diccionario, pedira por teclado un número de habitantes y mostrara el diccionario con nombre
y cantidad de habitantes con el número menor introducido.
"""

poblacion={}


while True:
    ciudad=input("Introduce una ciudad: (0 para salir): ").strip()
    if ciudad == "0" :
        break
    else:
        habitantes=input("Introduce una cantidad de habitantes: ").strip()

    if ciudad not in poblacion:
        poblacion[ciudad]=habitantes
    else:
        poblacion[ciudad]+=habitantes

print("Poblacion=", poblacion)

cantidad_habitantes=input("Introduce una cantidad de habitantes a buscar en el diccionario: ")


"""
Ejercicio3
Introducir una cadena de texto y crear un diccionario, contar las consonantes de cada palabra del diccionario.
"""

cadena = input("Introduce una cadena: ")

palabras = cadena.split()

contador_letras = 0

for palabra in cadena:
    for caracter in palabra:
        if caracter != "a" and caracter != "e" and caracter != "i" and caracter != "o" and caracter != "u":
            contador_letras += 1

print (palabras, contador_letras)

